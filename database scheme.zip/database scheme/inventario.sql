/*
SQLyog Ultimate v13.1.1 (64 bit)
MySQL - 10.4.26-MariaDB : Database - inventario
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`inventario` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `inventario`;

/*Table structure for table `categorias` */

DROP TABLE IF EXISTS `categorias`;

CREATE TABLE `categorias` (
  `idcategoria` int(11) NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(40) DEFAULT '',
  PRIMARY KEY (`idcategoria`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4;

/*Data for the table `categorias` */

/*Table structure for table `inventario` */

DROP TABLE IF EXISTS `inventario`;

CREATE TABLE `inventario` (
  `iditem` int(11) NOT NULL AUTO_INCREMENT,
  `codigo` varchar(40) DEFAULT '',
  `categoria` int(11) DEFAULT 0,
  `refinterna` varchar(20) DEFAULT NULL,
  `descripcion` varchar(200) DEFAULT '',
  `costo` decimal(11,2) DEFAULT 0.00,
  `precio_cliente` decimal(11,2) DEFAULT 0.00,
  `idproveedor` int(11) DEFAULT 1,
  `observaciones` text DEFAULT '',
  `imagenes` varchar(2000) DEFAULT NULL,
  PRIMARY KEY (`iditem`),
  UNIQUE KEY `inventario_idx1` (`codigo`)
) ENGINE=InnoDB AUTO_INCREMENT=578 DEFAULT CHARSET=utf8mb4;

/*Data for the table `inventario` */

/*Table structure for table `movimientos` */

DROP TABLE IF EXISTS `movimientos`;

CREATE TABLE `movimientos` (
  `idmovimientos` int(11) NOT NULL AUTO_INCREMENT,
  `codigo` varchar(40) DEFAULT NULL,
  `descripcion` varchar(200) DEFAULT '',
  `tipomovimiento` varchar(10) DEFAULT '',
  `fecha` datetime DEFAULT current_timestamp(),
  `cantidad` decimal(11,2) DEFAULT NULL,
  PRIMARY KEY (`idmovimientos`)
) ENGINE=InnoDB AUTO_INCREMENT=1029 DEFAULT CHARSET=utf8mb4;

/*Data for the table `movimientos` */

/*Table structure for table `proveedores` */

DROP TABLE IF EXISTS `proveedores`;

CREATE TABLE `proveedores` (
  `idproveedor` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(20) DEFAULT '',
  PRIMARY KEY (`idproveedor`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;

/*Data for the table `proveedores` */

/*Table structure for table `usuariosweb` */

DROP TABLE IF EXISTS `usuariosweb`;

CREATE TABLE `usuariosweb` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(60) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `fullname` varchar(200) DEFAULT NULL,
  `email` varchar(60) DEFAULT NULL,
  `login_session_key` varchar(255) DEFAULT NULL,
  `email_status` varchar(255) DEFAULT NULL,
  `password_expire_date` datetime DEFAULT '2023-02-16 00:00:00',
  `password_reset_key` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;

/*Data for the table `usuariosweb` */

/*Table structure for table `grafico` */

DROP TABLE IF EXISTS `grafico`;

/*!50001 DROP VIEW IF EXISTS `grafico` */;
/*!50001 DROP TABLE IF EXISTS `grafico` */;

/*!50001 CREATE TABLE  `grafico`(
 `codigo` varchar(61) ,
 `SALDO` decimal(33,2) ,
 `mov` bigint(21) 
)*/;

/*Table structure for table `inventario_saldos` */

DROP TABLE IF EXISTS `inventario_saldos`;

/*!50001 DROP VIEW IF EXISTS `inventario_saldos` */;
/*!50001 DROP TABLE IF EXISTS `inventario_saldos` */;

/*!50001 CREATE TABLE  `inventario_saldos`(
 `codigo` varchar(40) ,
 `descripcion` varchar(200) ,
 `SALDO` decimal(33,2) ,
 `categoria` varchar(40) 
)*/;

/*Table structure for table `saldosmenores` */

DROP TABLE IF EXISTS `saldosmenores`;

/*!50001 DROP VIEW IF EXISTS `saldosmenores` */;
/*!50001 DROP TABLE IF EXISTS `saldosmenores` */;

/*!50001 CREATE TABLE  `saldosmenores`(
 `codigo` varchar(40) ,
 `descripcion` varchar(200) ,
 `SALDO` decimal(33,2) ,
 `categoria` varchar(40) 
)*/;

/*View structure for view grafico */

/*!50001 DROP TABLE IF EXISTS `grafico` */;
/*!50001 DROP VIEW IF EXISTS `grafico` */;

/*!50001 CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `grafico` AS select concat(`inventario`.`codigo`,' ',substr(`inventario`.`descripcion`,1,20)) AS `codigo`,sum(`movimientos`.`cantidad`) AS `SALDO`,count(`movimientos`.`cantidad`) AS `mov` from (`inventario` join `movimientos` on(`inventario`.`codigo` = `movimientos`.`codigo`)) group by concat(`inventario`.`codigo`,' ',substr(`inventario`.`descripcion`,1,20)) order by count(`movimientos`.`cantidad`) desc limit 20 */;

/*View structure for view inventario_saldos */

/*!50001 DROP TABLE IF EXISTS `inventario_saldos` */;
/*!50001 DROP VIEW IF EXISTS `inventario_saldos` */;

/*!50001 CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `inventario_saldos` AS select `inventario`.`codigo` AS `codigo`,`inventario`.`descripcion` AS `descripcion`,sum(`movimientos`.`cantidad`) AS `SALDO`,`categorias`.`descripcion` AS `categoria` from ((`inventario` join `movimientos` on(`inventario`.`codigo` = `movimientos`.`codigo`)) join `categorias` on(`inventario`.`categoria` = `categorias`.`idcategoria`)) group by `inventario`.`codigo` order by `inventario`.`descripcion` */;

/*View structure for view saldosmenores */

/*!50001 DROP TABLE IF EXISTS `saldosmenores` */;
/*!50001 DROP VIEW IF EXISTS `saldosmenores` */;

/*!50001 CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `saldosmenores` AS select `inventario_saldos`.`codigo` AS `codigo`,`inventario_saldos`.`descripcion` AS `descripcion`,`inventario_saldos`.`SALDO` AS `SALDO`,`inventario_saldos`.`categoria` AS `categoria` from `inventario_saldos` where `inventario_saldos`.`SALDO` <= 10 */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
